"use strict";
exports.__esModule = true;
exports.DBConfig = {
    userName: 'lior',
    password: 'lM8%px35',
    server: '188.121.44.212',
    // If you're on Windows Azure, you will need this:
    options: { encrypt: true }
};
exports.emailConfig = {
    subject: 'message from my web site',
    apiKey: 'key-7fa3cfafbfdc3a2a28fec32029c88742',
    domain: 'sandbox185e99a6024a47928602c0edc1188d3e.mailgun.org',
    to: 'liorgish@gmail.com'
};
